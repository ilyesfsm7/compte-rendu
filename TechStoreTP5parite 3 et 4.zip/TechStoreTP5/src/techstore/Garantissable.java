package techstore;

public interface Garantissable {
	int grantirAppareil();
}
