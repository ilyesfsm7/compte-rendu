package techstore;

public class OrdinateurDeBureau
        extends Ordinateur {

    private String alimentation;

    public OrdinateurDeBureau(
            int id,
            String nom,
            String reference,
            double prix,
            double resolutionEcran,
            String processeur,
            long ram,
            SystemeExploitation systemeExploitation,
            long disqueDur,
            String carteGraphique,
            String alimentation) {

        super(id, nom, reference, prix,
                resolutionEcran,
                processeur,
                ram,
                systemeExploitation,
                disqueDur,
                carteGraphique);

        this.alimentation = alimentation;
    }

    @Override
    public int grantirAppareil() {
        return 1;
    }
}