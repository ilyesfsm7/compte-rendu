package techstore;

public class Test {

	public static void main(String[] args) {
		SystemeExploitation s1=SystemeExploitation.Windows;
		SystemeExploitation s2=SystemeExploitation.Ubuntu;
		System.out.println(s1);
		System.out.println(s2);
		for(SystemeExploitation s:SystemeExploitation.values()) {
			System.out.println(s);
		}
		OrdinateurPortable pcPortable =
                new OrdinateurPortable(
                        1,
                        "Dell Inspiron",
                        "DEL123",
                        1200,
                        15.6,
                        "Intel i7",
                        16,
                        SystemeExploitation.Windows,
                        1000,
                        "NVIDIA RTX 3050",
                        5000);

        OrdinateurDeBureau pcBureau =
                new OrdinateurDeBureau(
                        2,
                        "HP Gaming",
                        "HP456",
                        1500,
                        24,
                        "Intel i9",
                        32,
                        SystemeExploitation.Ubuntu,
                        2000,
                        "RTX 4070",
                        "750W");

        System.out.println("=== Ordinateur Portable ===");
        System.out.println(pcPortable);
        System.out.println("Garantie : "
                + pcPortable.grantirAppareil()
                + " ans");

        System.out.println();

        System.out.println("=== Ordinateur de Bureau ===");
        System.out.println(pcBureau);
        System.out.println("Garantie : "
                + pcBureau.grantirAppareil()
                + " ans");
	}

}
