package techstore;

public class ComposantStockage
        extends Article
        implements Garantissable {

    private int capacite;

    public ComposantStockage(
            int id,
            String nom,
            String reference,
            double prix,
            int capacite) {

        super(id, nom, reference, prix);
        this.capacite = capacite;
    }

    @Override
    public int grantirAppareil() {

        if (capacite <= 500)
            return 1;
        else
            return 2;
    }
}