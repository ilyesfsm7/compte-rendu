package techstore;

public abstract class Ordinateur
        extends AppareilInformatique {

    private long disqueDur;
    private String carteGraphique;

    public Ordinateur(
            int id,
            String nom,
            String reference,
            double prix,
            double resolutionEcran,
            String processeur,
            long ram,
            SystemeExploitation systemeExploitation,
            long disqueDur,
            String carteGraphique) {

        super(id, nom, reference, prix,
                resolutionEcran,
                processeur,
                ram,
                systemeExploitation);

        this.disqueDur = disqueDur;
        this.carteGraphique = carteGraphique;
    }

    @Override
    public abstract int grantirAppareil();
}