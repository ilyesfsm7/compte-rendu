package techstore;

public class Article {
	private int id;
	private String nom;
	private String reference;
	private double prix;
	public Article(int id, String nom,String reference,double prix ) {
		this.id = id;
		this.nom = nom;
		this.reference = reference;
		this.prix = prix;
	}
	public int getId() {
		return id;
	}
	public String getNom() {
		return nom;
	}	
	public String getReference() {
		return reference;
	}
	public double getPrix() {
		return prix;
	}
	@Override
	public String toString() {
		return "id="+id+"nom="+nom+"reference="+reference+"prix="+prix;
	}
}
