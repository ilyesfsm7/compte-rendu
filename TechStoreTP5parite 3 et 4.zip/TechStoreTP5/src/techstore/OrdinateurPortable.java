package techstore;

public class OrdinateurPortable
        extends Ordinateur {

    private long capaciteBatterie;

    public OrdinateurPortable(
            int id,
            String nom,
            String reference,
            double prix,
            double resolutionEcran,
            String processeur,
            long ram,
            SystemeExploitation systemeExploitation,
            long disqueDur,
            String carteGraphique,
            long capaciteBatterie) {

        super(id, nom, reference, prix,
                resolutionEcran,
                processeur,
                ram,
                systemeExploitation,
                disqueDur,
                carteGraphique);

        this.capaciteBatterie =
                capaciteBatterie;
    }

    @Override
    public int grantirAppareil() {
        return 2;
    }
}