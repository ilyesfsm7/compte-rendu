package heritage;

public interface Identifiable {
	void afficheridentite();
	
}
