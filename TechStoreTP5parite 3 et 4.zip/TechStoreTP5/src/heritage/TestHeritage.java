package heritage;

public class TestHeritage {

    public static void main(String[] args) {

        Adulte a1 =
            new Adulte("Amine", 35,
                       "22123456",
                       "Ingénieur");

        Enfant e1 =
            new Enfant("Sami", 10,
                       "99123456",
                       "École primaire");

        Bebe b1 =
            new Bebe("Lina", 1,
                     "55123456",
                     true);
        a1.afficheridentite();

        System.out.println(a1);
        System.out.println(e1);
        System.out.println(b1);

        System.out.println("Nom de l'adulte : " + a1.getNom());
        TypePersonne type =TypePersonne.ADULTE;
    	System.out.println(type);
    	for(TypePersonne t:TypePersonne.values()){
    		System.out.println(t);
    	
    	}
    }
}