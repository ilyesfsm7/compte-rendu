package heritage;

public enum TypePersonne {
	ADULTE,
	EBFANT,
	BEBE

}
