package techstoretp4;

import java.util.Scanner;

public class test {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        stock stock = new stock();

        stock.ajouterArticle("Apple iPad 8e Generation", 1269, 8);
        stock.ajouterArticle("Micro Casque 588 Filaire", 79, 15);
        stock.ajouterArticle("Samsung Galaxy Tab S9", 2200, 5);

        personne gerant = new personne(
                "01111111",
                "Kbayer",
                "Jasser",
                "Monastir",
                5000);

        System.out.println("=================================");
        System.out.println("GESTION DU STOCK TECHSTORE");
        System.out.println("=================================");
        System.out.println("Gerant : " + gerant);

        int choix;

        do {

            System.out.println("\n========== MENU ==========");
            System.out.println("1 - Ajouter un article");
            System.out.println("2 - Augmenter la quantite");
            System.out.println("3 - Modifier un article");
            System.out.println("4 - Supprimer un article");
            System.out.println("5 - Consulter le stock");
            System.out.println("0 - Quitter");

            System.out.print("Choix : ");
            choix = sc.nextInt();
            sc.nextLine();

            switch (choix) {

            case 1:

                System.out.print("Nom article : ");
                String nom = sc.nextLine();

                System.out.print("Prix : ");
                double prix = sc.nextDouble();

                System.out.print("Quantite : ");
                long qte = sc.nextLong();
                sc.nextLine();

                stock.ajouterArticle(nom, prix, qte);

                System.out.println("Article ajoute.");
                break;

            case 2:

                System.out.println(stock);

                System.out.print("Reference : ");
                String refAjout = sc.nextLine();

                System.out.print("Quantite a ajouter : ");
                long q = sc.nextLong();
                sc.nextLine();

                stock.incrementerQuantiteArticle(refAjout, q);

                System.out.println("Quantite mise a jour.");
                break;

            case 3:

                System.out.println(stock);

                System.out.print("Reference : ");
                String refMod = sc.nextLine();

                System.out.print("Nouveau nom : ");
                String nvNom = sc.nextLine();

                System.out.print("Nouveau prix : ");
                double nvPrix = sc.nextDouble();

                System.out.print("Nouvelle quantite : ");
                long nvQte = sc.nextLong();
                sc.nextLine();

                stock.modifierArticle(
                        refMod,
                        nvNom,
                        nvPrix,
                        nvQte);

                System.out.println("Article modifie.");
                break;

            case 4:

                System.out.println(stock);

                System.out.print("Reference : ");
                String refSup = sc.nextLine();

                stock.supprimerArticle(refSup);

                System.out.println("Article supprime.");
                break;

            case 5:

                System.out.println("\n===== STOCK =====");
                System.out.println(stock);

                break;

            case 0:

                System.out.println("Fin du programme.");
                break;

            default:

                System.out.println("Choix invalide.");

            }

        } while (choix != 0);

        sc.close();
    }
}





/*package techstoretp4;
import java.util.Scanner;
public class test {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        personne p = null;

        int choix;

        do {

            System.out.println("\n===== GESTION DES PERSONNES =====");
            System.out.println("1 - Ajouter une personne");
            System.out.println("2 - Modifier le nom");
            System.out.println("3 - Modifier le prenom");
            System.out.println("4 - Modifier l'adresse");
            System.out.println("5 - Afficher la personne");
            System.out.println("0 - Quitter");
            System.out.print("Choix : ");

            choix = sc.nextInt();
            sc.nextLine();

            switch (choix) {

            case 1:

                System.out.print("CIN : ");
                String cin = sc.nextLine();

                System.out.print("Nom : ");
                String nom = sc.nextLine();

                System.out.print("Prenom : ");
                String prenom = sc.nextLine();

                System.out.print("Gouvernorat : ");
                String gouvernorat = sc.nextLine();

                System.out.print("Code postal : ");
                int codePostal = sc.nextInt();
                sc.nextLine();

                p = new personne(cin, nom, prenom,
                                 gouvernorat, codePostal);

                System.out.println("Personne ajoutee avec succes.");
                break;

            case 2:

                if (p != null) {
                    System.out.print("Nouveau nom : ");
                    p.setNom(sc.nextLine());
                    System.out.println("Nom modifie.");
                } else {
                    System.out.println("Ajoutez d'abord une personne.");
                }

                break;

            case 3:

                if (p != null) {
                    System.out.print("Nouveau prenom : ");
                    p.setPrenom(sc.nextLine());
                    System.out.println("Prenom modifie.");
                } else {
                    System.out.println("Ajoutez d'abord une personne.");
                }

                break;

            case 4:

                if (p != null) {

                    System.out.print("Nouveau gouvernorat : ");
                    String gov = sc.nextLine();

                    System.out.print("Nouveau code postal : ");
                    int cp = sc.nextInt();
                    sc.nextLine();

                    p.setAdresse(new adresse(gov, cp));

                    System.out.println("Adresse modifiee.");
                } else {
                    System.out.println("Ajoutez d'abord une personne.");
                }

                break;

            case 5:

                if (p != null)
                    System.out.println(p);
                else
                    System.out.println("Aucune personne enregistree.");

                break;

            case 0:

                System.out.println("Fin du programme.");
                break;

            default:

                System.out.println("Choix invalide.");
            }

        } while (choix != 0);

        sc.close();
    }
}*/