package techstoretp4;

public class adresse {
	private String gouvernorat;
	private int codepostale;
	public adresse (String gouvernorat,int codepostale){
		this.gouvernorat=gouvernorat;
		this.codepostale=codepostale;	
		
		
	}

	public String getgouvernorat() {
		return gouvernorat;	
	}
	public int getcodepostale() {
		return codepostale;
		
		
	}
	public void setgouvernorat(String gouvernorat) {
		this.gouvernorat=gouvernorat;	
	}
	public void setcodepostale(int codepostale) {
		this.codepostale=codepostale;		
	}
	@Override
	public String toString() {
		return "adresse [gouvernrat="+gouvernorat+", code postale"+codepostale+"]";
		
	}
}
