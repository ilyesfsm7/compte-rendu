package techstoretp4;
public class personne {
    private String cin;
    private String nom;
    private String prenom;
    private adresse adresse;
    public personne(String cin, String nom, String prenom, adresse adresse) {
        this.cin = cin;
        this.nom = nom;
        this.prenom = prenom;
        this.adresse = adresse;
    }
    public personne(String cin, String nom, String prenom,
                    String gouvernorat, int codePostal) {
        this(cin, nom, prenom, new adresse(gouvernorat, codePostal));
    }
    public String getCin() {
        return cin;
    }
    public String getNom() {
        return nom;
    }
    public String getPrenom() {
        return prenom;
    }
    public adresse getAdresse() {
        return adresse;
    }
    public void setCin(String cin) {
        this.cin = cin;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }
    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public void setAdresse(adresse adresse) {
        this.adresse = adresse;
    }
    @Override
    public String toString() {
        return "cin=" + cin +
                ", nom=" + nom +
                ", prenom=" + prenom +
                ", " + adresse;
    }
}