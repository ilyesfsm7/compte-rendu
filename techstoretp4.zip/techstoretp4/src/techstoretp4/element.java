package techstoretp4;

public class element {
	private article article;
	private long quantite;
	 public element(article article, long quantite) {
	        this.article = article;
	        this.quantite = Math.max(0, quantite);
	    }
	public element(String nom,double prix ,long quantite) {
		this.article=new article(nom,prix);
		this.quantite=Math.max(0, quantite);
		
	}public article getArticle() {
		return article;
	}
	public long getQuantite() {
		return quantite;
	}
	public String getnomarticle() {
	return article.getNom();
		
	}
	public String getrefarticle() {
		return article.getRef();
			
		}
	public double getprixarticle() {
		return article.getPrix();
			
		}
	public void setArticle(article article) {
		this.article = article;
	}
	
	public void setQuantite(long quantite) {
		this.quantite = quantite;
	}
	public void incrementerQuantite(long q) {
		if (q>0) {
			quantite+=q;
		}
		
	}
	public void decrementerQuantite(long q) {
		if (quantite>0 &&q<quantite) {
			quantite-=q;
		}
		
	}
	public void modifier(String nom,double prix,long quantite) {
		this.article=new article(nom,prix);
		this.quantite=quantite;
	
	}
	public boolean equals(String reference) {
		return article.getRef().equals(reference);
		
	}
	public boolean equals(article article) {
		return article.getRef().equals(this.article.getRef());
		
	}
	@Override
    public String toString() {
        return "Element [article=" + article +
                ", quantite=" + quantite + "]";
    }
	

}
