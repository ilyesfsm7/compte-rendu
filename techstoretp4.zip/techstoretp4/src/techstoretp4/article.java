package techstoretp4;

public class article {
	private static int compteur=0;
	private int id;
	private String nom;
	private String ref;
	private double prix;
	public article(String nom, double prix) {
		this.id=++compteur;
		this.nom=nom;
		this.prix=prix;
		this.ref=genererref();
	}
	private String genererref() {
		String ch=nom.replace(" ", "");
		String ref="";
		for(int i=0;i<ch.length();i++) {
			if(i%5==0) {
				ref+=ch.charAt(i);
			}
		ref+=id;
		}
				
		return ref;

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getRef() {
		return ref;
	}

	public void setRef(String ref) {
		this.ref = ref;
	}

	public double getPrix() {
		return prix;
	}

	public void setPrix(double prix) {
		this.prix = prix;
	}
	public void modifier(String nom) {
		setNom(nom);
	}
	public void modifier(String nom,double prix) {
		setNom(nom);
		setPrix(prix);
	}
	 @Override
	    public String toString() {
	        return "id=" + id +
	                ", nom=" + nom +
	                ", reference=" + ref +
	                ", prix=" + prix;
	    }
}
