package techstoretp4;

import java.util.ArrayList;

public class stock {

    private ArrayList<element> articleList;

    public stock() {
        articleList = new ArrayList<>();
    }

    public stock(ArrayList<element> articleList) {
        this.articleList = articleList;
    }

    public stock(ArrayList<String> noms,
                 ArrayList<Double> prix,
                 ArrayList<Long> quantites) {

        articleList = new ArrayList<>();

        for (int i = 0; i < noms.size(); i++) {
            articleList.add(
                    new element(
                            noms.get(i),
                            prix.get(i),
                            quantites.get(i)));
        }
    }

    public ArrayList<element> getArticleList() {
        return articleList;
    }

    public int getArticleNb() {
        return articleList.size();
    }

    public void setArticleList(ArrayList<element> articleList) {
        this.articleList = articleList;
    }

    public void ajouterArticle(article article, long q) {
        articleList.add(new element(article, q));
    }

    public void ajouterArticle(String nom,
                               double prix,
                               long q) {

        articleList.add(
                new element(nom, prix, q));
    }

    public element trouverArticle(String reference) {

        for (element e : articleList) {
            if (e.equals(reference))
                return e;
        }

        return null;
    }

    public void modifierArticle(String reference,
                                String nom,
                                double prix,
                                long quantite) {

        element e = trouverArticle(reference);

        if (e != null) {
            e.modifier(nom, prix, quantite);
        }
    }

    public void supprimerArticle(String reference) {

        element e = trouverArticle(reference);

        if (e != null)
            articleList.remove(e);
    }

    public void incrementerQuantiteArticle(String reference,
                                           long q) {

        element e = trouverArticle(reference);

        if (e != null)
            e.incrementerQuantite(q);
    }

    public void decrementerQuantiteArticle(String reference,
                                           long q) {

        element e = trouverArticle(reference);

        if (e != null)
            e.decrementerQuantite(q);
    }

    @Override
    public String toString() {

        String ch = "";

        for (element e : articleList) {
            ch += e + "\n";
        }

        return ch;
    }
}